@extends('Product.layout')
     @section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2></h2>
            </div>
            <div class="pull-right">
               
				<a onclick="create_product()" class="btn btn-success" >Add New Product</a>
            </div>
        </div>
    </div>
    
  
     <div>
        <h3>Product Details</h3>
        <table id="datatable" class="data-table table stripe hover nowrap table-bordered" >
            <thead>
                <tr align="left">
                    <th>Sr.NO</th>
                    <th data-sortable="true">Prodect Name</th>
                    <th data-sortable="false">Product Price</th>
                    <th data-sortable="false">Product Description</th>
					<th data-sortable="false">Show</th>
					<th data-sortable="false">Edit </th>
					<th data-sortable="false">Delete </th>
					
					
					
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
<script>
    $(document).ready(function(){
        $('#datatable').DataTable({
            processing: true,
            serverSide: true,
            order: [[ 0, "ASC" ]],
            ajax: "{{ url('users-data') }}",
            columns: [
                { data: 'id' },
                { data: 'product_name' },
                { data: 'product_price' },
                { data: 'product_desccription' },
				{ data: 'product_desccription' },
				{ data: 'Edit' },
				{ data: 'Delete' }
				
            ]
        });
    });
	
	function create_product()
	{
var base_url = {!! json_encode(url('/')) !!};

 
 window.location.href = base_url+'/Product/create'; 
 
		
}		
</script>
    
        
@endsection